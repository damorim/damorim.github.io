% UIUC++ Summer Research in Software Engineering (SRSE) 2026
% Screening Task

# Context and Motivation

Property-based testing tools such as
[Hypothesis](https://hypothesis.readthedocs.io/en/latest/) generate
structured random inputs and verify whether they satisfy specified
properties. However, property-based testing can struggle to produce
diverse and valid inputs when properties involve complex or tightly
constrained conditions, as input generation becomes increasingly
restrictive.

Satisfiability Modulo Theory (SMT) solvers such as
[Z3](https://github.com/z3prover/z3) can efficiently determine the
satisfiability of logical constraints and generate concrete satisfying
assignments for those constraints, when they exist. For that reason,
these solvers have the potential to circumvent a central limitation of
property-based tools.

# Background on Property-based Testing

The following Python code snippet shows an example of property-based
test written in the hypothesis library, which integrates with the
pytest testing framework:

```python
from hypothesis import given
import hypothesis.strategies as st

# Property: sorting preserves elements and order
@given(st.lists(st.integers()))
def test_sort_properties(xs):
    sorted_xs = sorted(xs)

    # 1. It is sorted
    assert all(sorted_xs[i] <= sorted_xs[i+1] for i in range(len(sorted_xs)-1))

    # 2. It is a permutation of original
    assert sorted(sorted_xs) == sorted(xs)
```

Running this test shows the following output:


```
$> pytest -s --hypothesis-show-statistics
============= test session starts ============= 
platform darwin -- Python 3.12.13, pytest-9.0.3, pluggy-1.6.0
rootdir: /Users/damorim/removeme/property_based_testing
plugins: hypothesis-6.152.4
collected 1 item

test_list.py .
============= Hypothesis Statistics =============

test_list.py::test_sort_properties:

  - during generate phase (0.03 seconds):
    - Typical runtimes: < 1ms, of which < 1ms in data generation
    - 100 passing examples, 0 failing examples, 21 invalid examples

  - Stopped because settings.max_examples=100
```

Note that pytest+hypothesis created several inputs to test the
properties defined through assert statements and that all generate
inputs satisfy the two defined properties.

Hypothesis trigger strategy objects to produce these inputs. In this
case, it identifies that it needs to create "lists with integer
elements" and find a specific strategy (i.e., generator) to create
those inputs.  Note that, although the generation strategy
@given(st.lists(st.integers())) did not indicate any constraints to
satisfy, hypothesis internally rejected some inputs (see ``invalid
example'').

It is very common for developers to constraint the input space that
the test should consider. In fact, imposing such constraints is often
necessary as the property is valid only within those conditions.

In the following example, the developer restricts the range of
integers x and y to 1-100 for efficiency.

```
from hypothesis import given
import hypothesis.strategies as st

@given(st.integers(min_value=1, max_value=100), st.integers(min_value=1, max_value=100))
def test_multiplication(x, y):
    # no need for assume()
    assert (x * y) >= x
```

Here is another example where the constraint is specified within the
test.

```
@given(st.integers(), st.integers())
def test_division_property(x, y):
    # constraint inside the property
    assume(y != 0)
    assume(x % y == 0)
    # property
    assert (x // y) * y == x
```

# Background on SMT solving

Satisfiability Modulo Theory (SMT) is the problem of determining
whether logical formulas with respect to background theories (such as
integers, arrays, or bit-vectors) are satisfiable. xZ3 is a
high-performance SMT solver that finds such satisfying assignments or
proves that none exist.

This example shows how z3 (using Python frontend) can produce one
satisfying solution for the constraint appearing in the last PBT
example:

```
from z3 import Int, Solver, sat

# variables
x = Int("x")
y = Int("y")

# solver
s = Solver()

# constraints
s.add(y != 0)
s.add(x % y == 0)

# optional: keep search bounded (otherwise infinite space)
s.add(x >= -10, x <= 10)
s.add(y >= -10, y <= 10)

# solve
if s.check() == sat:
    m = s.model()
    print("x =", m[x])
    print("y =", m[y])
else:
    print("No solution")
```

The output you obtain when running this code:

```
$> python z3_example.py 
x = 0
y = 1
```


# Screening Task: Property-Based Testing and SMT Translation

This screening task evaluates your ability to analyze real-world
property-based testing (PBT) usage in Python projects and translate
selected tests into constraint-based input generators using SMT
solving. You will work with a popular Python project that uses
property-based testing (e.g., Hypothesis-based test suites) and
perform empirical analysis followed by a small formal methods
translation.

## 1. Identify a Target Project

Select one **popular Python project** that uses property-based
testing, preferably built with Hypothesis. Examples include large
open-source projects (NumPy, pandas, JAX, etc.), but you are free to
choose any suitable repository.

## 2. Empirical Analysis

Compute the following statistics:

- **Number of property-based tests (PBTs)**  

  Defined as tests using `@given`.

- **Number of PBTs that declare constraints**, including any of:

  - strategy arguments (e.g., `min_value`, `max_size`, `min_size`)

  - `assume(...)`

  - `.filter(...)`

Provide a short explanation of how you identified these tests.

## 3. SMT-Based Translation

Select **2–3 representative property-based tests** and:

- Extract the input strategies used

- Identify all input constraints

- Translate these constraints into SMT formulas using Z3

For each selected test:

- Implement a **custom input generator**

- Replace random generation with SMT-based solving

- Ensure the generator produces inputs that satisfy the original constraints

You may use LLMs to assist in translating constraints into SMT, but you must ensure correctness of the final implementation.

## 4. Repository Submission

Create a GitHub repository containing:

- Scripts reproducing the original property-based tests [[ don't need to copy the original project; mock as needed ]]

- SMT-based generator implementations

- A short comparison document

The comparison should discuss:

- Feasibility of SMT-based generation

- Differences between PBT and SMT-based strategies

- Limitations or mismatches encountered during translation

## 5. Partial Completion

If you cannot complete all steps, include a document describing:

- Where SMT translation failed or became difficult

- Which types of constraints were hard to encode

- Any simplifying assumptions you made

- Any scalability or performance issues observed
