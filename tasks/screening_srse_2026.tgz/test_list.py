from hypothesis import given
import hypothesis.strategies as st

# Property: sorting preserves elements and order
@given(st.lists(st.integers()))
def test_sort_properties(xs):
    sorted_xs = sorted(xs)

    # 1. It is sorted
    assert all(sorted_xs[i] <= sorted_xs[i+1] for i in range(len(sorted_xs)-1))

    # 2. It is a permutation of original
    assert sorted(sorted_xs) == sorted(xs)
