from z3 import Int, Solver, sat

# variables
x = Int("x")
y = Int("y")

# solver
s = Solver()

# constraints
s.add(y != 0)
s.add(x % y == 0)

# optional: keep search bounded (otherwise infinite space)
s.add(x >= -10, x <= 10)
s.add(y >= -10, y <= 10)

# solve
if s.check() == sat:
    m = s.model()
    print("x =", m[x])
    print("y =", m[y])
else:
    print("No solution")
